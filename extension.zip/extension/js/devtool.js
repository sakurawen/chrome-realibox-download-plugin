import"./chunk/modulepreload-polyfill-ed0eab8c.js";browser.devtools.panels.create("Download Plugin","","index.html");
